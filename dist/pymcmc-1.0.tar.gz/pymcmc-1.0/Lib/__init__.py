## Figures out which function we expose
## eg
## from stream_function_wrapper import zm_msf
